JustPDFit Public Plugin Package 0.6.1

Contains a portable Agent Plugins plugin.json and MCP configuration.
The MCP server URL is https://justpdfit-chatgpt-mcp.onrender.com/mcp.
This ZIP is a candidate upload to OpenAI Platform for validation; it has not been reviewed or approved.
Important outstanding requirements after draft upload:
- Select the verified publisher identity.
- Verify MCP server domain using the token shown by OpenAI.
- Complete server scan and remedy any findings.
- Provide an actual reviewer-accessible demo video URL in the portal/package.
- Validate ChatGPT attachment handoff and final PDF download within the host.
- Review legal/privacy text and policy attestations truthfully.
- After approval, publication requires a separate step.

Official icon source: /justpdfit-icon.svg on the JustPDFit website.
